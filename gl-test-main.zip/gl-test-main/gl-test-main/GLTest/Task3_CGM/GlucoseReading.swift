import Foundation

enum GlucoseTrend: Sendable {
    case rising, steady, falling
}

struct GlucoseReading: Identifiable, Sendable, Equatable {
    let id = UUID()
    let value: Int
    let timestamp: Date
    let trend: GlucoseTrend
}
