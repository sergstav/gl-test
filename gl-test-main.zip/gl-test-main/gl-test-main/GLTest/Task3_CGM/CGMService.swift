import Combine
import Foundation

final class CGMService {
    let readings = PassthroughSubject<GlucoseReading, Never>()

    private(set) var isConnected = false
    private var timer: DispatchSourceTimer?
    private let sensorQueue = DispatchQueue(label: "com.gltest.cgm.sensor")
    private var lastValue = 120

    func connect() {
        guard !isConnected else { return }
        isConnected = true

        let timer = DispatchSource.makeTimerSource(queue: sensorQueue)
        timer.schedule(deadline: .now() + 1, repeating: 1)
        timer.setEventHandler { [weak self] in
            self?.emitReading()
        }
        timer.resume()
        self.timer = timer
    }

    func disconnect() {
        isConnected = false
        timer?.cancel()
        timer = nil
    }

    private func emitReading() {
        let delta = Int.random(in: -12...12)
        let newValue = min(max(lastValue + delta, 40), 300)
        let trend: GlucoseTrend =
            newValue > lastValue ? .rising :
            newValue < lastValue ? .falling : .steady
        lastValue = newValue

        let reading = GlucoseReading(value: newValue, timestamp: Date(), trend: trend)
        readings.send(reading)
    }
}
