# Task 3 · Continuous glucose monitor

`CGMService` publishes a `GlucoseReading` on a fixed interval while it is connected.

**Your job:**

1. Read `CGMService` and note any pain points you see. Talk them through.
2. Build a screen that shows the latest glucose reading and its timestamp.
3. Let the user connect and disconnect the sensor.

Build your view and view model in this folder — replace the placeholder in `CGMView`.
Keep the view passive and put logic in a view model. Add new files as needed.
