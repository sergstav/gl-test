import SwiftUI

struct CGMView: View {
    var body: some View {
        TaskPlaceholder(
            title: "Continuous Glucose Monitor",
            instructions: "Analyse CGMService, then build the view + view model. Add a connect/disconnect toggle and show the latest reading with its timestamp."
        )
    }
}
