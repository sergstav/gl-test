import Combine
import Foundation

final class CounterViewModel: ObservableObject {
    @Published var count = 0
    @Published var fact = ""

    private let service = FactService()
    private var cancellables = Set<AnyCancellable>()

    init() {
        $count
            .flatMap { number in
                self.service.factPublisher(for: number)
            }
            .assign(to: \.fact, on: self)
            .store(in: &cancellables)
    }

    func increment() {
        count += 1
    }

    func decrement() {
        count -= 1
    }
}
