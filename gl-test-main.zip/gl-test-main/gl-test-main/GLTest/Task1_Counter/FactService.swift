import Combine
import Foundation

final class FactService {
    func factPublisher(for number: Int) -> AnyPublisher<String, Never> {
        Future { promise in
            DispatchQueue.global().asyncAfter(deadline: .now() + 0.6) {
                promise(.success(Self.fact(for: number)))
            }
        }
        .eraseToAnyPublisher()
    }

    private static func fact(for number: Int) -> String {
        let facts = [
            "\(number) is the number of the day.",
            "In binary, \(number) is \(String(number, radix: 2)).",
            "\(number) squared is \(number * number).",
        ]
        return facts[abs(number) % facts.count]
    }
}
