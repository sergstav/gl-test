import SwiftUI

struct CounterView: View {
    @ObservedObject var viewModel = CounterViewModel()

    var body: some View {
        VStack(spacing: 24) {
            Text("\(viewModel.count)")
                .font(.system(size: 72, weight: .bold, design: .rounded))
                .contentTransition(.numericText())

            Text(viewModel.fact.isEmpty ? "Tap + to load a fact" : viewModel.fact)
                .font(.callout)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .frame(minHeight: 44)
                .padding(.horizontal)

            HStack(spacing: 16) {
                Button {
                    viewModel.decrement()
                } label: {
                    Image(systemName: "minus")
                        .frame(width: 56, height: 56)
                }
                Button {
                    viewModel.increment()
                } label: {
                    Image(systemName: "plus")
                        .frame(width: 56, height: 56)
                }
            }
            .buttonStyle(.borderedProminent)
            .font(.title)
        }
        .padding()
        .navigationTitle("Counter")
        .navigationBarTitleDisplayMode(.inline)
    }
}
