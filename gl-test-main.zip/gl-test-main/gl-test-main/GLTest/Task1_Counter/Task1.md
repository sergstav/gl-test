# Task 1 · Counter

`CounterView`, `CounterViewModel` and `FactService` implement a counter that also loads
a short "fact" about the current number.

**Your job:** read the three files and tell us what you would change, and why. Think
about correctness, threading, memory, architecture and testability.

Fixing anything is optional — the discussion matters most. If you have time, pick the
change you think is most important and make it.
