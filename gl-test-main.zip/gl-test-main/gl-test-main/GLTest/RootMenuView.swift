import SwiftUI

struct RootMenuView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Warm-ups") {
                    TaskRow(
                        number: 1,
                        title: "Counter",
                        subtitle: "Analyse the code — what would you change?",
                        destination: CounterView()
                    )
                    TaskRow(
                        number: 2,
                        title: "First non-repeating character",
                        subtitle: "Implement the algorithm",
                        destination: FirstNonRepeatingView()
                    )
                }
                Section("Build") {
                    TaskRow(
                        number: 3,
                        title: "Continuous glucose monitor",
                        subtitle: "Analyse the service, then build the UI",
                        destination: CGMView()
                    )
                    TaskRow(
                        number: 4,
                        title: "Batch upload service",
                        subtitle: "Design and build the service",
                        destination: UploadDemoView()
                    )
                }
            }
            .navigationTitle("GL Test")
        }
    }
}

private struct TaskRow<Destination: View>: View {
    let number: Int
    let title: String
    let subtitle: String
    let destination: Destination

    var body: some View {
        NavigationLink {
            destination
        } label: {
            HStack(spacing: 12) {
                Text("\(number)")
                    .font(.headline.monospacedDigit())
                    .frame(width: 30, height: 30)
                    .background(Circle().fill(Color.accentColor.opacity(0.15)))
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline)
                    Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 4)
        }
    }
}

#Preview {
    RootMenuView()
}
