# Task 2 · First non-repeating character

Implement `FirstNonRepeating.firstNonRepeatingCharacter(in:)`.

It should return the first character in the string that does not repeat anywhere in the
string, or `nil` if there is no such character (or the string is empty).

| Input   | Output |
|---------|--------|
| "swiss" | "w"    |
| "aabbc" | "c"    |
| "aabb"  | nil    |
| ""      | nil    |

- `FirstNonRepeatingView` is a small screen where you can type inputs and see the result live.
- There are starter unit tests in `GLTestTests/FirstNonRepeatingTests.swift` — make them
  pass, then add any cases you think are worth covering.

Be ready to talk about time and space complexity.
