import Foundation

enum FirstNonRepeating {
    static func firstNonRepeatingCharacter(in input: String) -> Character? {
        nil
    }
}
