import SwiftUI

struct FirstNonRepeatingView: View {
    @State private var input = "swiss"

    private var result: Character? {
        FirstNonRepeating.firstNonRepeatingCharacter(in: input)
    }

    var body: some View {
        Form {
            Section("Input") {
                TextField("Type a string", text: $input)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            }
            Section("First non-repeating character") {
                if let result {
                    Text(String(result)).font(.largeTitle.monospaced())
                } else {
                    Text("nil")
                        .font(.largeTitle.monospaced())
                        .foregroundStyle(.secondary)
                }
            }
            Section("Try these") {
                ForEach(["swiss", "aabbc", "aabb", "racecars", "🇬🇧🇬🇧🇫🇷", ""], id: \.self) { example in
                    Button(example.isEmpty ? "(empty string)" : example) {
                        input = example
                    }
                }
            }
        }
        .navigationTitle("First Non-Repeating")
        .navigationBarTitleDisplayMode(.inline)
    }
}
