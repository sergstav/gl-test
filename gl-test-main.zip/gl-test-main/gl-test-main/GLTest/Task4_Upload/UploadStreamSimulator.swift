import Foundation

enum UploadStreamSimulator {
    static func makeStreams(count: Int = 3, perStream: Int = 20) -> [AsyncStream<DataItem>] {
        (0 ..< count).map { streamIndex in
            AsyncStream { continuation in
                let task = Task {
                    for itemIndex in 0 ..< perStream {
                        try? await Task.sleep(for: .milliseconds(Int.random(in: 50 ... 250)))
                        continuation.yield(DataItem(payload: "stream\(streamIndex)-item\(itemIndex)"))
                    }
                    continuation.finish()
                }
                continuation.onTermination = { _ in task.cancel() }
            }
        }
    }
}
