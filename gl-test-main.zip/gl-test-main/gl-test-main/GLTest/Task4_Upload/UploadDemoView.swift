import SwiftUI

struct UploadDemoView: View {
    var body: some View {
        TaskPlaceholder(
            title: "Batch Upload Service",
            instructions: "Open UploadService.swift and implement the batch-upload logic. Talk through your actor / Sendable / concurrency decisions. Optionally drive it from here."
        )
    }
}
