# Task 4 · Batch upload service

Build a shared service that collects data from several concurrent producers and uploads
it in batches.

**Requirements**

- Multiple async streams provide `DataItem`s concurrently.
- Cache items in a 5×5 matrix: up to 5 rows, each holding up to 5 items.
- When the matrix is full (25 items), perform a batch upload.
- Upload rows **concurrently** — one upload request per row.
- A row that uploads successfully is cleared.
- A row whose upload fails is kept for the next batch.
- The service is used across the app.

**What's provided**

- `Uploader` / `MockUploader` — the upload API; `MockUploader` simulates a flaky network
  (it fails at random). Tune the failure rate as you like.
- `UploadStreamSimulator` — produces the concurrent streams of `DataItem`s.
- `UploadService` — a stub for you to implement.
- `RecordingUploader` in `GLTestTests/UploadServiceTests.swift` — a deterministic test double.

Implement `UploadService` and talk through your isolation, `Sendable` and concurrency
decisions as you go. You can optionally drive it from `UploadDemoView`.
