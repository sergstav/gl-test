import Foundation

struct DataItem: Sendable, Equatable, Identifiable {
    let id: UUID
    let payload: String

    init(id: UUID = UUID(), payload: String) {
        self.id = id
        self.payload = payload
    }
}
