import Foundation

enum UploadError: Error {
    case network
}

protocol Uploader: Sendable {
    func upload(_ items: [DataItem]) async throws
}

struct MockUploader: Uploader {
    var failureRate: Double = 0.25

    func upload(_ items: [DataItem]) async throws {
        try await Task.sleep(for: .milliseconds(Int.random(in: 200...700)))
        if Double.random(in: 0...1) < failureRate {
            throw UploadError.network
        }
    }
}
