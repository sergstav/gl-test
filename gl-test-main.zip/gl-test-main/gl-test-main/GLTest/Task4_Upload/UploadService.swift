import Foundation

actor UploadService {
    private let uploader: Uploader

    init(uploader: Uploader) {
        self.uploader = uploader
    }

    func ingest(_ item: DataItem) {
    }

    func consume(_ stream: AsyncStream<DataItem>) async {
        for await item in stream {
            ingest(item)
        }
    }

    private func uploadBatch() async {
    }
}
