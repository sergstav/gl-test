import SwiftUI

@main
struct GLTestApp: App {
    var body: some Scene {
        WindowGroup {
            RootMenuView()
        }
    }
}
