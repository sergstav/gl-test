# GL Test

A short iOS take-home / live-coding exercise for senior engineers. It contains four
independent tasks. Some ask you to **analyse** existing code; others ask you to
**build** something. There are no trick questions — talk through your thinking as you
go, and ask the interviewer anything you'd ask a teammate.

## Requirements

- Xcode 16 or newer
- An iOS 18 simulator (any iPhone)

## Running

1. Open `GLTest.xcodeproj`.
2. Select an iPhone simulator.
3. `Cmd + R` to run. The home screen links to each task.

## The tasks

Each task has its own brief (`TaskN.md`) in its folder:

| # | Task | Type | Brief |
|---|------|------|-------|
| 1 | Counter | analyse | `GLTest/Task1_Counter/Task1.md` |
| 2 | First non-repeating character | implement | `GLTest/Task2_FirstNonRepeating/Task2.md` |
| 3 | Continuous glucose monitor | analyse + build | `GLTest/Task3_CGM/Task3.md` |
| 4 | Batch upload service | design + build | `GLTest/Task4_Upload/Task4.md` |
