import XCTest
@testable import GLTest

final class UploadServiceTests: XCTestCase {
    actor RecordingUploader: Uploader {
        private(set) var uploadedRows: [[DataItem]] = []
        private var remainingFailures: Int

        init(failuresBeforeSuccess: Int = 0) {
            remainingFailures = failuresBeforeSuccess
        }

        func upload(_ items: [DataItem]) async throws {
            if remainingFailures > 0 {
                remainingFailures -= 1
                throw UploadError.network
            }
            uploadedRows.append(items)
        }
    }

    func testPlaceholder() {
        XCTAssertTrue(true)
    }
}
