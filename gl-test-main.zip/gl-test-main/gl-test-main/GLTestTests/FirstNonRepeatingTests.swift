import XCTest
@testable import GLTest

final class FirstNonRepeatingTests: XCTestCase {
    func testFirstNonRepeatingInSwiss() {
        XCTAssertEqual(FirstNonRepeating.firstNonRepeatingCharacter(in: "swiss"), "w")
    }

    func testReturnsLastCharacter() {
        XCTAssertEqual(FirstNonRepeating.firstNonRepeatingCharacter(in: "aabbc"), "c")
    }

    func testAllRepeatingReturnsNil() {
        XCTAssertNil(FirstNonRepeating.firstNonRepeatingCharacter(in: "aabb"))
    }

    func testEmptyStringReturnsNil() {
        XCTAssertNil(FirstNonRepeating.firstNonRepeatingCharacter(in: ""))
    }
}
